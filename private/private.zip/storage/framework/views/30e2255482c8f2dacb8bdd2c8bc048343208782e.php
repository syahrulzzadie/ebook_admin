<?php use App\Helpers\AppHelpers; ?>

<?php echo $__env->make('template.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <span class="m-0 font-weight-bold text-primary">
            <i class="fa fa-table mr-2"></i>Data Diskusi
        </span>
        <a href="<?php echo e(route('diskusi.create')); ?>" class="btn btn-sm btn-success float-right">
            <i class="fa fa-plus mr-2"></i>Tambah Data
        </a>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table id="datatable" class="table table-bordered table-sm w-100">
                <thead class="bg-primary text-white">
                    <tr>
                        <th>Judul</th>
                        <th>Keterangan</th>
                        <th>Tanggal</th>
                        <th>Pengguna</th>
                        <th>Detail</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data_diskusi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diskusi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($diskusi->judul); ?></td>
                        <td><?php echo e(Str::limit($diskusi->ket, 60)); ?></td>
                        <td><?php echo e($diskusi->tanggal); ?></td>
                        <td><?php echo e($diskusi->pengguna->nama); ?></td>
                        <td>
                            <a class="btn btn-sm btn-secondary" href="<?php echo e(route('diskusi.detail', $diskusi->id_diskusi)); ?>">
                                <i class="fa fa-eye mr-2"></i>Detail
                            </a>
                        </td>
                        <td><?php echo AppHelpers::buttonActions('diskusi', $diskusi->id_diskusi); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script type="text/javascript">
    function deleteData(form) {
        if (confirm('Apakah anda yakin?')) {
            $(form).submit();
        }
    }
    $(document).ready(function() {
        $('#datatable').DataTable();
    });
</script>

<?php echo $__env->make('template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ebook_admin\private\resources\views/diskusi/index.blade.php ENDPATH**/ ?>