<?php use App\Helpers\AppHelpers; ?>

<?php echo $__env->make('template.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <span class="m-0 font-weight-bold text-primary">
            <i class="fa fa-plus mr-2"></i>Tambah Data
        </span>
        <a href="<?php echo e(route('karya_tulis.index')); ?>" class="btn btn-sm btn-secondary float-right">
            <i class="fa fa-arrow-left mr-2"></i>Kembali
        </a>
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('karya_tulis.store')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label>Judul</label>
                <input type="text" name="judul" class="form-control" placeholder="Judul.." required>
            </div>
            <div class="form-group">
                <label>Sinopsis</label>
                <textarea name="sinopsis" class="form-control" placeholder="Sinopsis.." required></textarea>
            </div>
            <div class="form-group">
                <label>Kategori</label>
                <input type="text" name="kategori" class="form-control" placeholder="Kategori.." required>
            </div>
            <div class="form-group">
                <label>Isi</label>
                <textarea name="isi" class="form-control" placeholder="Isi.." required></textarea>
            </div>
            <div class="form-group">
                <label>Pengguna</label>
                <select name="id_pengguna" class="form-control" required>
                    <?php $__currentLoopData = $data_pengguna; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengguna): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($pengguna->id_pengguna); ?>"><?php echo e($pengguna->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label>Sampul</label>
                <input type="file" name="sampul" accept="image/*" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Publish</label>
                <select name="publish" class="form-control" required>
                    <option value="publish">Publish</option>
                    <option value="draft">Draft</option>
                </select>
            </div>
            <div class="form-group text-center mt-4">
                <button type="submit" class="btn btn-primary"><i class="fa fa-save mr-2"></i>Simpan Data</button>
            </div>
        </form>
    </div>
</div>

<?php echo $__env->make('template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ProjectLaravel\ebook_admin\resources\views/karya_tulis/create.blade.php ENDPATH**/ ?>