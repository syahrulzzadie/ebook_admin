<?php use App\Helpers\AppHelpers; ?>

<?php echo $__env->make('template.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <span class="m-0 font-weight-bold text-primary">
            <i class="fa fa-table mr-2"></i>Data Karya Tulis
        </span>
        <a href="<?php echo e(route('karya_tulis.create')); ?>" class="btn btn-sm btn-success float-right">
            <i class="fa fa-plus mr-2"></i>Tambah Data
        </a>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table id="datatable" class="table table-bordered table-sm w-100">
                <thead class="bg-primary text-white">
                    <tr>
                        <th>Judul</th>
                        <th>Sinopsis</th>
                        <th>Tanggal</th>
                        <th>Kategori</th>
                        <th>Pengguna</th>
                        <th>Sampul</th>
                        <th>Publish</th>
                        <th>Isi</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data_karya_tulis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $karya_tulis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($karya_tulis->judul); ?></td>
                        <td><?php echo e(Str::limit($karya_tulis->sinopsis, 50)); ?></td>
                        <td><?php echo e($karya_tulis->tanggal); ?></td>
                        <td><?php echo e($karya_tulis->kategori); ?></td>
                        <td><?php echo e($karya_tulis->pengguna->nama); ?></td>
                        <td><?php echo AppHelpers::image($karya_tulis->sampul, 120); ?></td>
                        <td><?php echo e($karya_tulis->publish); ?></td>
                        <td><?php echo e(Str::limit($karya_tulis->isi, 50)); ?></td>
                        <td><?php echo AppHelpers::buttonActions('karya_tulis', $karya_tulis->id_karya_tulis); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script type="text/javascript">
    function deleteData(form) {
        if (confirm('Apakah anda yakin?')) {
            $(form).submit();
        }
    }
    $(document).ready(function() {
        $('#datatable').DataTable();
    });
</script>

<?php echo $__env->make('template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ProjectLaravel\ebook_admin\resources\views/karya_tulis/index.blade.php ENDPATH**/ ?>