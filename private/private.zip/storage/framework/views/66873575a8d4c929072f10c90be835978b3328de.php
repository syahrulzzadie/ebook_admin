<?php use App\Helpers\AppHelpers; ?>

<?php echo $__env->make('template.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <span class="m-0 font-weight-bold text-primary">
            <i class="fa fa-plus mr-2"></i>Edit Data
        </span>
        <a href="<?php echo e(route('event.index')); ?>" class="btn btn-sm btn-secondary float-right">
            <i class="fa fa-arrow-left mr-2"></i>Kembali
        </a>
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('event.update', $event->id_event)); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <div class="form-group">
                <label>Judul</label>
                <input type="text" name="judul" class="form-control" placeholder="Judul.." value="<?php echo e($event->judul); ?>" required>
            </div>
            <div class="form-group">
                <label>Keterangan</label>
                <input type="text" name="ket" class="form-control" placeholder="Keterangan.." value="<?php echo e($event->ket); ?>" required>
            </div>
            <div class="form-group">
                <label>Isi</label>
                <textarea name="isi" class="form-control" placeholder="Isi.." required><?php echo e($event->isi); ?></textarea>
            </div>
            <div class="form-group">
                <label>Pengguna</label>
                <select id="id_pengguna" name="id_pengguna" class="form-control" required>
                    <?php $__currentLoopData = $data_pengguna; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengguna): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($pengguna->id_pengguna); ?>"><?php echo e($pengguna->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label>Sampul <small>(Kosongkan jika tidak di ubah)</small></label>
                <input type="file" name="sampul" accept="image/*" class="form-control">
            </div>
            <div class="form-group text-center mt-4">
                <button type="submit" class="btn btn-primary"><i class="fa fa-save mr-2"></i>Simpan Data</button>
            </div>
        </form>
    </div>
</div>

<script type="text/javascript">
$(document).ready(function() {
    $("#id_pengguna").val('<?php echo e($event->id_pengguna); ?>');
});
</script>

<?php echo $__env->make('template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ebook_admin\private\resources\views/event/show.blade.php ENDPATH**/ ?>